import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TabsPage } from './tabs.page';

const routes: Routes = [
  {
    path: 'tabs',
    component: TabsPage,
    children: [
      {
        path: 'chatlist',
        loadChildren: () => import('../pages/chatlist/chatlist.module').then(m => m.ChatlistPageModule)
      },
      
      {
        path: 'canallist',
        loadChildren: () => import('../pages/canallist/canallist.module').then(m => m.CanallistPageModule)
      },

      {
        path: '',
        redirectTo: '/tabs/chatlist',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: '',
    redirectTo: '/tabs/chatlist',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
})
export class TabsPageRoutingModule {}
