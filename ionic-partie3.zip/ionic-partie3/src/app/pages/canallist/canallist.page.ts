import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-canallist',
  templateUrl: './canallist.page.html',
  styleUrls: ['./canallist.page.scss'],
})
export class CanallistPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
