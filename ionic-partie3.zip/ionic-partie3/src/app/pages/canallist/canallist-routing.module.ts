import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { CanallistPage } from './canallist.page';

const routes: Routes = [
  {
    path: '',
    component: CanallistPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CanallistPageRoutingModule {}
