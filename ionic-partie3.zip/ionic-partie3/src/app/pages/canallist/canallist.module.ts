import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { CanallistPageRoutingModule } from './canallist-routing.module';

import { CanallistPage } from './canallist.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    CanallistPageRoutingModule
  ],
  declarations: [CanallistPage]
})
export class CanallistPageModule {}
