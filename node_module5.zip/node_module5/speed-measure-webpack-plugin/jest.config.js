module.exports = {
  testPathIgnorePatterns: ["__tests__"],
  testURL: "http://localhost",
};
