import { ChromiumCommandList } from '../interfaces';
export declare let chromium: ChromiumCommandList;
