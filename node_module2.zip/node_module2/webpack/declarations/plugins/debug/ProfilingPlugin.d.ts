/**
 * This file was automatically generated.
 * DO NOT MODIFY BY HAND.
 * Run `yarn special-lint-fix` to update
 */

export interface ProfilingPluginOptions {
	/**
	 * Path to the output file e.g. `profiling/events.json`. Defaults to `events.json`.
	 */
	outputPath?: string;
}
