/* globals __webpack_amd_options__ */
module.exports = __webpack_amd_options__;
